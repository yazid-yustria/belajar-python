#membuat
#open('file_pertama.txt','x')

#membaca
#file = open('file_pertama.txt','r')
#print(file.read())

#mengisi
#file = open('file_pertama.txt','w')
#file.write("Selamat Datang")
#file.write("\n")
#file.write("Nama saya Yustria")
#file.close()

#menambah
file = open('file_pertama.txt','a')
file.write ("\n")
file.write ("ini baris baru")
file.close()

