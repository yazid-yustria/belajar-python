def circle_perimeter(radius):
  phi = 22/7
  result = 2 * radius * phi
  text= f"The perimeter of the circle is {result}"
  print(text)