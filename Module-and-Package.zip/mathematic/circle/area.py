def circle_area(radius):
  phi=22/7
  result= phi * radius * radius
  text= f"area of the circle is {result}"
  print(text)