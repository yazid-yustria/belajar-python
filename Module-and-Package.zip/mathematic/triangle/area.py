def triangle_area(base,height):
  result=1/2 * base * height
  text = f"the area of triangle is {result}"
  print(text)