def triangle_perimeter(a, b, c):
  result = a + b + c
  text = f"The perimeter of the triangle is {result}"
  print(text)