def square_perimeter(side):
  result = 4*side
  text= f"The perimeter of the square is {result}"
  print(text)