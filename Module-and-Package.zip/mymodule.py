def area_of_square(side):
    result=side * side
    text = f"the area of square is {result}"
    print(text)

def area_of_triangle(base,height):
    result=1/2 * base * height
    text = f"the area of triangle is {result}"
    print(text)